from pydantic_settings import BaseSettings
from typing import Optional, List
from urllib.parse import quote_plus, urlparse
import logging
import os

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

class Settings(BaseSettings):
    PROJECT_NAME: str = "Employee Management System"
    VERSION: str = "1.0.0"
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 8  # 8 days
    DATABASE_URL: str
    ENV: str = "production"  # Add environment setting
    FIRST_SUPERUSER_EMAIL: str = "admin@example.com"
    FIRST_SUPERUSER_PASSWORD: str = "admin123"

    # CORS Settings
    CORS_ORIGINS: str = ""  # Accept as string and parse in property

    @property
    def cors_origins(self) -> List[str]:
        return [origin.strip() for origin in self.CORS_ORIGINS.split(",") if origin.strip()]

    @property
    def parsed_database_url(self) -> str:
        logger.debug("Starting database URL parsing")

        # Log raw URL first
        logger.debug(f"Raw DATABASE_URL received: {self.DATABASE_URL}")

        if not self.DATABASE_URL:
            logger.error("DATABASE_URL is empty or None")
            raise ValueError("DATABASE_URL is required")

        # Log URL structure without credentials
        logger.debug(f"Raw DATABASE_URL structure (no credentials): {self.DATABASE_URL.split('@')[1] if '@' in self.DATABASE_URL else 'Invalid format'}")

        try:
            # Parse URL components
            parsed = urlparse(self.DATABASE_URL)

            # Validate components
            missing_components = []
            if not parsed.scheme: missing_components.append("scheme")
            if not parsed.hostname: missing_components.append("hostname")
            if not parsed.username: missing_components.append("username")
            if not parsed.password: missing_components.append("password")

            if missing_components:
                raise ValueError(f"Missing URL components: {', '.join(missing_components)}")

            # URL encode the password
            safe_password = quote_plus(parsed.password)
            logger.debug(f"Password successfully encoded (length: {len(safe_password)})")

            # Reconstruct URL with encoded password
            url = f"{parsed.scheme}://{parsed.username}:{safe_password}@{parsed.hostname}"
            if parsed.port:
                url += f":{parsed.port}"
            url += f"{parsed.path}"
            if parsed.query:
                url += f"?{parsed.query}"

            logger.debug(f"URL structure validation successful: {parsed.scheme}://{parsed.username}:****@{parsed.hostname}{parsed.path}")
            return url

        except Exception as e:
            logger.error(f"Database URL parsing failed: {str(e)}")
            logger.error("Expected format: postgresql://user:password@host:port/dbname")
            logger.error(f"Received scheme: {parsed.scheme if 'parsed' in locals() else 'None'}")
            logger.error(f"Received hostname: {parsed.hostname if 'parsed' in locals() else 'None'}")
            raise ValueError(f"Invalid database URL format: {str(e)}")

    class Config:
        case_sensitive = True
        env_file = ".env"

settings = Settings()
