#!/bin/bash
set -e

# Debug: Print environment variables
echo "DEBUG: Environment variables:"
echo "DATABASE_URL=$DATABASE_URL"
echo "SECRET_KEY=$SECRET_KEY"
echo "CORS_ORIGINS=$CORS_ORIGINS"

# Function to get database connection details from DATABASE_URL
get_db_details() {
    if [ -z "$DATABASE_URL" ]; then
        echo "ERROR: DATABASE_URL environment variable is not set"
        exit 1
    fi

    echo "DEBUG: Parsing DATABASE_URL: $DATABASE_URL"
    # Parse DATABASE_URL with or without port
    regex_with_port="postgresql?://([^:]+):([^@]+)@([^:]+):([^/]+)/(.*)"
    regex_without_port="postgresql?://([^:]+):([^@]+)@([^/]+)/(.*)"

    if [[ $DATABASE_URL =~ $regex_with_port ]]; then
        export DB_USER="${BASH_REMATCH[1]}"
        export DB_PASS="${BASH_REMATCH[2]}"
        export DB_HOST="${BASH_REMATCH[3]}"
        export DB_PORT="${BASH_REMATCH[4]}"
        export DB_NAME="${BASH_REMATCH[5]%%\?*}"  # Remove query parameters
    elif [[ $DATABASE_URL =~ $regex_without_port ]]; then
        export DB_USER="${BASH_REMATCH[1]}"
        export DB_PASS="${BASH_REMATCH[2]}"
        export DB_HOST="${BASH_REMATCH[3]}"
        export DB_PORT="5432"  # Default PostgreSQL port
        export DB_NAME="${BASH_REMATCH[4]%%\?*}"  # Remove query parameters
    else
        echo "ERROR: Invalid DATABASE_URL format"
        exit 1
    fi
}

# Get database details
get_db_details

# Wait for the database to be ready
echo "Waiting for database to be ready..."
python << END
import sys
import time
import psycopg2
while True:
    try:
        psycopg2.connect(
            dbname="${DB_NAME}",
            user="${DB_USER}",
            password="${DB_PASS}",
            host="${DB_HOST}",
            port="${DB_PORT}"
        )
        break
    except psycopg2.OperationalError as e:
        print("Database not ready. Waiting... Error:", str(e))
        time.sleep(2)
END

# Run migrations
echo "Running database migrations..."
if [ ! -f /app/alembic/versions/*.py ]; then
    echo "No migrations found. Creating initial migration..."
    # Drop and recreate alembic_version table
    python << END
import psycopg2
conn = psycopg2.connect(dbname="${DB_NAME}", user="${DB_USER}", password="${DB_PASS}", host="${DB_HOST}", port="${DB_PORT}")
cur = conn.cursor()
cur.execute("DROP TABLE IF EXISTS alembic_version")
conn.commit()
conn.close()
END
    alembic revision --autogenerate -m "initial migration"
fi
alembic upgrade head

# Create initial data
echo "Creating initial data..."
python -m app.initial_data

# Start the application with configurable workers
WORKERS=${WORKERS:-4}
PORT=8001
echo "Starting application with $WORKERS workers on port $PORT..."
exec uvicorn app.main:app --host 0.0.0.0 --port $PORT --workers $WORKERS
